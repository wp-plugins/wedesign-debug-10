<?php
/*
	Plugin Name: Wedesign Debug
	Plugin URI: http://wedesign.ca/
	Description: DEBUG Module for WordPress.
	Author: Aaron Fay
	Version: 1.0
	Author URI: http://aaronfay.ca/
*/

# I MAY ONE DAY USE THE DB RATHER THAN SESSIONS, THAT MIGHT SOLVE SOME HEADACHES
# I MAY ALOS ANOTHER DAY CLEAN UP THIS MESS AND PUT PROPER COMMENTS IN, ALL THE 
# JAVADOC COMMENTS, AREN'T MINE...AS YOU CAN TELL ;)

# OH, AND THE USUAL STUFF:

/* ************************************************************************ */
/*																			*/
/*  Wedesign-Debug 1.0														*/
/*  Copyright (c)2007 Aaron Fay												*/
/*																			*/
/* This program is free software; you can redistribute it and/or			*/
/* modify it under the terms of the GNU Lesser General Public				*/
/* License as published by the Free Software Foundation; either				*/
/* version 2.1 of the License, or (at your option) any later version.		*/
/*																			*/
/* This program is distributed in the hope that it will be useful,			*/
/* but WITHOUT ANY WARRANTY; without even the implied warranty of			*/
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU		*/
/* Lesser General Public License or the LICENSE file for more details.		*/
/*																			*/
/* Some portions of this program may be derivative of other works and		*/
/* are subject to the copyrights of their respective owners.				*/
/*																			*/
/* ************************************************************************ */


//sessions are needed if we are debugging inside any of the wp- pages where
//redirects are present...the debug variables are stored in the session until the 
//redirected page comes up
session_start();

//grab the microtime
$wd_debug_interval = $wd_debug_time = microtime_float();


//check to see if stored data exists
if(count($_SESSION['wd_debug'])){
	wd_debug_session($_SESSION['wd_debug']);
	unset($_SESSION['wd_debug']);
}

$_SESSION['wd_debug'] = array();

//this will be the super-function
function wd_output(){
	$env = debug_backtrace();
	$env = "<strong>".addslashes($env[0]['file']).": ".$env[0]['line']."</strong> ".$env[0]['function']."()";
	$args = func_get_args();
	debug_newline($env);
	for($i=0;$i<count($args);$i++){
		//if the string of the current item starts with "m:" it is 
		//intended as the marker or "name" of the value, and they 
		//will be displayed together
		//if(strpos($args[$i],"m")==0&&strpos($args[$i],":")==1){
		if(strstr($args[$i],"m:")){
			debug_var(substr($args[$i],2),$args[$i+1]);
			$i++; //skip one
		} else {
			debug_var(gettype($args[$i]),$args[$i]);
			//debug_var(gettype($args[$i]),$env2);			
		}
	}	
}
//stores in session rather than outputting
function wd_store(){
	$env = debug_backtrace();
	$env = "<strong>".strrchr($env[0]['file'],'\\').": ".$env[0]['line']."</strong> ".$env[0]['function']."()";
	$args = func_get_args();
	for($i=0;$i<count($args);$i++){
		//if the string of the current item starts with "m:" it is 
		//intended as the marker or "name" of the value, and they 
		//will be displayed together
		//if(strpos($args[$i],"m")==0&&strpos($args[$i],":")==1){
		if(strstr($args[$i],"m:")){
			wd_debug_store(substr($args[$i],2),$args[$i+1],$env, $i);
			$i++; //skip one
		} else {
			wd_debug_store(gettype($args[$i]),$args[$i],$env, $i);
		}
	}	
}


//stores items in the session var
function wd_debug_store($name, $data, $env="<strong>Output:</strong>", $key=0){

	if(!is_array($_SESSION['wd_debug'])){
		$_SESSION['wd_debug'] = array();
	}
	$_SESSION['wd_debug']["$env"][$key] = array("$name", $data);
}

//wrapper for the timers
function wd_timer(){
	global $wd_debug_time, $wd_debug_interval;
	
	//get the values
	$now = microtime_float();
	$wd_interval = round($now-$wd_debug_interval,3);
	
	$wd_time = round($now-$wd_debug_time,3);
	//reset the timers
	$wd_debug_interval = microtime_float();
	
	//send out the data
	return "Total <strong>{$wd_time}s</strong>  Interval <strong>{$wd_interval}s</strong>";
}



/**
* take session data for wordpress and output it to the console
*
* @access public
* @param $array Array session data
* @return null
* @global
*/
function wd_debug_session($array){
	foreach($array as $line => $data){
		debug_newline($line);
		foreach($data as $key => $value){
			debug_var($value[0], $value[1]);
		}
		//debug_var('array: ', $array);
	}
}


/**
* print debug information to the current debug window
*
* @access public
* @param $name string variable name
* @param $data unknown variable
* @return null
* @global
*/
function debug_var($name, $data)
{
	$cookie_enabled = intval(get_settings('debug_cookie_enabled'));
	if($cookie_enabled && !$_COOKIE['wd_debug_cookie']){
		return false;
	}
	$debug_enabled = intval(get_settings('debug_enabled'));
	if($debug_enabled){
		
		debug_open_window();
		$captured = explode("\n",debug_capture_print_r($data));
		print "<script language='Javascript'>\n";
		print "version=0;\n";
		print "if (navigator.appVersion.indexOf('MSIE')!=-1){\n";
		print "temp=navigator.appVersion.split('MSIE')\n";
		print "version=parseFloat(temp[1])\n";
		print "}\n";
		print "if (version>=5.5){var ie=true}else{var ie=false}";
		//print "debugWindow.document.writeln('<p style=\'padding:0;margin:-12px 0 8px 0;color:#666666;\'><small>$line</small></p>');\n";
		print "debugWindow.document.writeln('<b style=\'text-decoration:underline;margin-left:15px\'>$name:</b>');\n";
		print "if(ie){debugWindow.document.writeln('<pre style=\'padding:0;margin:0 0 10px 20px;\'>');}else{debugWindow.document.writeln('<pre style=\'padding:0;margin:-9px 0 10px 20px;\'>');}\n";
		//print "debugWindow.document.writeln('<pre style=\'padding:0;margin:-9px 0 10px 20px;\'>');\n";
		foreach($captured as $line)
		{
			print "debugWindow.document.writeln('".debug_colorize_string($line)."');\n";
		}
		print "debugWindow.document.writeln('</pre>');\n";
		print "debugWindow.scroll(0,1000000);\n";
		print "self.focus();\n";
		print "</script>\n";
	}
}
function debug_newline($line='<strong>Output:</strong>')
{
	$cookie_enabled = intval(get_settings('debug_cookie_enabled'));
	if($cookie_enabled && !$_COOKIE['wd_debug_cookie']){
		return false;
	}
	$debug_enabled = intval(get_settings('debug_enabled'));
	if($debug_enabled){
		
		debug_open_window();
		print "<script language='Javascript'>\n";
		print "debugWindow.document.writeln('<p style=\'padding:0;margin:-4px 0 8px 0;color:#666666;\'><small>$line</small></p>');\n";

		print "self.focus();\n";
		print "</script>\n";
	}
}

/**
* print a message to the debug window
*
* @access public
* @param $mesg string message to display
* @return null
* @global
*/
function debug_msg($mesg)
{
	$debug_enabled = intval(get_settings('debug_enabled'));
	if($debug_enabled){
		debug_open_window();
		print "<script language='JavaScript'>\n";
		print "debugWindow.document.writeln('".trim(nl2br($mesg))."<br>');\n";
		print "self.focus();\n";
		print "</script>\n";
	}
}

/**
* open a debug window for display
*
* this function may be called multiple times
* it will only print the code to open the
* remote window the first time that it is called.
*
* @access private
* @return null
* @global
*/
function debug_open_window()
{
    static $window_opened = FALSE;
    if(!$window_opened)
    {
        ?>
        <script language="JavaScript">
        debugWindow = window.open("","debugWin","toolbar=no,scrollbars,width=850,height=600,resizable=yes");
        debugWindow.document.writeln('<html>');
        debugWindow.document.writeln('<head>');
        debugWindow.document.writeln('<title>PHP Remote Debug Window</title>');
        debugWindow.document.writeln('</head>');
        debugWindow.document.writeln('<body style="font-size:11px"><font face="verdana,arial">');
        debugWindow.document.writeln('<hr size=1 width="100%" style="padding:0;margin:0">');
		debugWindow.document.writeln('<span style="color:red; padding-bottom:12px; float:right;font-weight:bold">Console Output - <?php echo date('H:i:s d-m-Y', time());?></span><br />');
        </script>
        <?php
        $window_opened = TRUE;
    }
}


/**
* catch the contents of a print_r into a string
*
* @access private
* @param $data unknown variable
* @return string print_r results
* @global
*/
function debug_capture_print_r($data)
{
    ob_start();
    print_r($data);

    $result = ob_get_contents();
	//get the string ready for js (FF)
	$result = trim(str_replace("\r", " ", addslashes($result)));
	$result = str_replace("\t", " ", $result);
	
    ob_end_clean();

    return $result;
}


/**
* colorize a string for pretty display
*
* @access private
* @param $string string info to colorize
* @return string HTML colorized
* @global
*/
function debug_colorize_string($string){
    /* turn array indexes to red */
    $string = str_replace('[','[<font color="red">',$string);
    $string = str_replace(']','</font>]',$string);
    /* turn the word Array blue */
    $string = str_replace('Array','<font color="blue">Array</font>',$string);
    /* turn arrows graygreen */
    $string = str_replace('=>','<font color="#556F55">=></font>',$string);
    return $string;
}

function microtime_float()
{
   list($usec, $sec) = explode(" ", microtime());
   return ((float)$usec + (float)$sec);
}

/**************************************************************************************************/
// PAGES FOR DEBUG PLUGIN MANAGEMENT

//options page
function wd_debug_page(){

	$debug_mode = get_settings('debug_enabled');
	$cookie_mode = get_settings('debug_cookie_enabled');

	/*


	//set cookie
	if(isset($_REQUEST['wd_set_cookie'])&&$_REQUEST['wd_set_cookie']!=''){
			$site = get_bloginfo('url');
			//overrides the domain and sets a cookie for the whole site
			setcookie('wd_debug_cookie','true', mktime(1,0,0,1,1,2020), '/', false);
			//header("Location: options-general.php?page=wedesign\wedesign-debug.php");
			//exit;
	}
	//unset cookie
	if(isset($_REQUEST['wd_unset_cookie'])&&$_REQUEST['wd_unset_cookie']!=''){
			$site = get_bloginfo('url');
			setcookie('wd_debug_cookie', '', time()-36000, '/', false);
			//header("Location: options-general.php?page=wedesign\wedesign-debug.php");
			//exit;
	}
	*/

	if(isset($_REQUEST['submit'])){
		$update = $_REQUEST['debug_enabled'] ? "1" : "0";
		if($update!=$debug_mode){
			update_option('debug_enabled', $update);
			$text = $update?"on":"off";
			echo "<div id='message' class='updated fade'><p>Debug mode {$text}.</p></div>";
			$debug_mode=$update;
		}
		$cupdate = $_REQUEST['debug_cookie_enabled'] ? "1" : "0";
		if($cupdate!=$cookie_mode){
			update_option('debug_cookie_enabled', $cupdate);
			$text = $cupdate?"on":"off";
			echo "<div id='message' class='updated fade'><p>Cookie mode {$text}.</p></div>";
			$cookie_mode=$cupdate;
		}
	}

	//wd_output("m:backend",$_COOKIE);
	//$cookie = get_post_meta(0, 'debug_ip', false);
	if($cookie_mode && !$_COOKIE['wd_debug_cookie']){
	//if($cookie_mode && !$cookie){
		$wd_cookie_form = "<p class='submit'><input type='submit' name='wd_set_cookie' value='Set me a cookie!' /></p>";
	} else {
		$wd_cookie_form = "You have the debug cookie. <p class='submit'><input type='submit' name='wd_unset_cookie' value='Unset my cookie!' /></p>";
	}
	
## DEBUG CONSOLE ############################################
//wd_output("m:cookie", $_COOKIE);
#############################################################

	
	echo '<div class="wrap">' .
		 '<h2>Debugging</h2>';
	$checked = $debug_mode ? " checked='checked'" : "";
	$cookie = $cookie_mode ? " checked='checked'" : "";
	echo "
	<form method='post' action=''>
	<h3><input type='checkbox' name='debug_enabled'{$checked}/> Enable Debug Mode ? </h3><br />
	<h3><input type='checkbox' name='debug_cookie_enabled'{$cookie}/> Enable Cookie Mode ? (Uses cookies) </h3><br />
	<p class='submit'><input type='submit' name='submit' value='Save' /></p>
	$wd_cookie_form
	</form>";

	/*echo "
	<style type='text/css'>
	.comment{
		color:#FF9900;
	}
	.string{
		color:#CC0000;
	}
	.code{
		color:blue;
	}
	blockquote{
		background-color:#FFFFee;
	}

	</style>
	<h2>Reference</h2>
	<h3>Overview</h3>
	<p>Debugging in PHP is often a challenging experience.  Debugging in WordPress has become even less fun sometimes 
	in that data we want to evaluate may be within a portion of the engine that doesn't output data, but redirects to
	another page entirely.  The need to ouput some data here forces us to break the page, and enter into a series of 
	goofy and cumbersome navigations to get the result we want, and then fix the page that was broken.  <strong>This is no longer necessary.</strong>
	</p>
	<p><strong>WordPress Debugger 0.1</strong> attempts to alleviate all your troubles.  This simple API allows you to use 
	simple functions to output data to a separate 'console' window.  When it is necessary to do so within a 'redirect' page, the 
	data is stored within a PHP session variable, and then retrieved for output.  Currently, <strong>string</strong>, <strong>array</strong>,
	 and <strong>object</strong> data types are supported, and arrays are color-coded for your viewing pleasure...On to the goods!
	</p>
	<h3>Function Reference</h3>
	<p><strong>debug_msg(<em>message</em> String)</strong><br />
	Outputs a message to the console window (opens one if not already open).
	Example:
	<blockquote>
	<code>
		\$var = <span class='string'>'apples '</span>; <span style='color:orange'>//notice the extra space</span><br />
		debug_msg(<span class='string'>'I like to eat '</span><span class='code'>.trim(</span>\$var<span class='code'>).</span><span class='string'>'.'</span>);
	</code>
	</blockquote>
	will output:
	<blockquote>
	<code>
		I like to eat apples.
	</code>
	</blockquote>
	</p>
	";*/

	echo '</div>';

}

//try and fix the cookie-setting part
function wd_set_me_a_cookie(){

	//wd_output("m:function start",$_REQUEST);
	
	//set cookie
	if(isset($_REQUEST['wd_set_cookie']) && $_REQUEST['wd_set_cookie'] != ''){
			$site = get_bloginfo('url');
			//overrides the domain and sets a cookie for the whole site
			setcookie('wd_debug_cookie','true', mktime(1,0,0,1,1,2020), '/', false);
			//header("Location: options-general.php?page=wedesign\wedesign-debug.php");
			//header("Location: options-general.php");
			//exit;
	}
	//unset cookie
	if(isset($_REQUEST['wd_unset_cookie']) && $_REQUEST['wd_unset_cookie'] != ''){
	
			//wd_store("m:before unset",$_COOKIE);
	
			$site = get_bloginfo('url');
			//setcookie('wd_debug_cookie', '', time() - 36000, '/', false);
			unset($_COOKIE["wd_debug_cookie"]);
			//wd_output("m:after unset",$_COOKIE);
			//header("Location: options-general.php?page=wedesign\wedesign-debug.php");
			//header("Location: options-general.php");
			//exit;
	}
}
add_action('init', 'wd_set_me_a_cookie');

//hook function
function wd_add_debug_page() {
	//Add a new menu under Options:
	add_options_page('Debug', 'Debug', 5, __FILE__, 'wd_debug_page');

}
//hook
add_action('admin_menu', 'wd_add_debug_page');



function wd_firebug(){
	echo  '<script language="javascript" type="text/javascript" src="' . get_bloginfo('url') . '/wp-content/plugins/wedesign/wedesign-debug/firebug/firebug.js"></script>';
}
//add_action('wp_head', 'wd_firebug');
//add_action('admin_head', 'wd_firebug');
?>