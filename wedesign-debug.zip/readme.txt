=== Wedesign Debug 1.0 ===
Contributors: Aaron Fay, Craig Davis
Donate link: http://aaronfay.ca/plugin-wedesign-debug/
Tags: wordpress, debug, output
Requires at least: 1.5
Tested up to: 2.1.2
Stable tag: 1.0

Wedesign Debug is a simple way to debug your Wordpress Development without echoing or printing statements into your site's templates.

== Description ==

Wedesign Debug 1.0 is based on a php debug script written in a tutorial by Craig Davis for Zend Developer Zone.  The simple script
outputs your data preformatted to a popunder 'console' window (handy if you have a secondary monitor).  The plugin also includes a timer
method for profiling your functions and an option to use cookies to trigger the debug methods so your output is transparent to your visitors/client.

== Installation ==

1.Download the plugin.
2.Activate on your Plugins page.
3.Place `<?php wd_output('Hello World'); ?>` anywhere in your wordpress development.

== Frequently Asked Questions ==

= Where can I get more information about this plugin? =

http://aaronfay.ca/plugin-wedesign-debug/ has the full API.



